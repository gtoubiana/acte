# Documentation de Acte

## Installation :

```
$ npm install acte --save
```

## API de référence :

## API des constantes et fonctions privées :
- [Constantes privées](/blob/master/src/js/private/constants/README.md#constantes-privées-utilisées-dans-acte).
- [Fonctions privées](/blob/master/src/js/private/functions/README.md#fonctions-privées-utilisées-dans-acte).
* * *
Créé et maintenu par [Gilles Toubiana](https://github.com/gtoubiana/) - 2015-Présent.<br>
[Code](https://github.com/gtoubiana/acte) sous licence [MIT](https://github.com/gtoubiana/acte/blob/master/LICENSE), [documentation](https://github.com/gtoubiana/acte/blob/master/dist/README.md) sous licence [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/deed.fr).
